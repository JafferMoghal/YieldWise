from flask import Flask, request, jsonify
import pickle
import numpy as np

# Load the trained model and encoders
try:
    with open('demand_model.pkl', 'rb') as f:
        model, encoders = pickle.load(f)  # encoders is a dictionary of LabelEncoders
except Exception as e:
    raise RuntimeError(f"Failed to load model and encoders: {e}")

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    print("\n📥 Received request:", data)

    required_fields = ["crop", "price_per_kg", "season", "region", "grade", "market_type"]
    missing_fields = [field for field in required_fields if field not in data]
    if missing_fields:
        return jsonify({"error": f"Missing fields: {', '.join(missing_fields)}"}), 400

    try:
        # Normalize and extract input values
        crop = data["crop"].lower().strip()
        price_per_kg = float(data["price_per_kg"])
        season = data["season"].lower().strip()
        region = data["region"].lower().strip()
        grade = data["grade"].lower().strip()
        market_type = data["market_type"].lower().strip()

        # Encode all categorical fields
        try:
            crop_encoded = encoders["crop"].transform([crop])[0]
            season_encoded = encoders["season"].transform([season])[0]
            region_encoded = encoders["region"].transform([region])[0]
            grade_encoded = encoders["grade"].transform([grade])[0]
            market_type_encoded = encoders["market_type"].transform([market_type])[0]
        except ValueError as ve:
            return jsonify({"error": str(ve)}), 400

        # Construct input vector: [crop_encoded, price_per_kg, season_encoded, region_encoded, grade_encoded, market_type_encoded]
        input_vector = [
            crop_encoded,
            price_per_kg,
            season_encoded,
            region_encoded,
            grade_encoded,
            market_type_encoded
        ]

        # Predict
        prediction = model.predict([input_vector])
        predicted_quantity = float(prediction[0])

        print("✅ Prediction complete:", predicted_quantity)
        return jsonify({"predicted_quantity": predicted_quantity})

    except Exception as e:
        print("❌ Exception during prediction:", str(e))
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=3002, debug=True)
