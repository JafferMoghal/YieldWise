import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder
import pickle

# Load and normalize dataset
data = pd.read_csv("demand_data.csv")
data["crop"] = data["crop"].str.lower().str.strip()
data["season"] = data["season"].str.lower().str.strip()
data["region"] = data["region"].str.lower().str.strip()
data["grade"] = data["grade"].str.lower().str.strip()
data["market_type"] = data["market_type"].str.lower().str.strip()

# Initialize and apply encoders for categorical features
encoders = {}

for column in ["crop", "season", "region", "grade", "market_type"]:
    le = LabelEncoder()
    data[column + "_encoded"] = le.fit_transform(data[column])
    encoders[column] = le

# Define features and label
X = data[[
    "crop_encoded",
    "price_per_kg",
    "season_encoded",
    "region_encoded",
    "grade_encoded",
    "market_type_encoded"
]]
y = data["quantity_demanded"]

# Train the model
model = LinearRegression()
model.fit(X, y)

# Save the model and all encoders
with open("demand_model.pkl", "wb") as f:
    pickle.dump((model, encoders), f)

print("✅ Model trained and saved to demand_model.pkl with extended features.")
