const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const axios = require("axios");
const mongoose = require("mongoose");

// MongoDB Models
const Farmer = require("./models/Farmer");
const Buyer = require("./models/Buyer");
const Contract = require("./models/Contract");
const MarketAssessment = require("./models/MarketAssessment");
let Prediction;
try {
  Prediction = require("./models/Prediction"); // Optional if file exists
} catch {
  console.warn("⚠️ Prediction model not found. Prediction count will be zero.");
}

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
const uri = "mongodb://127.0.0.1:27017/yieldwise";
mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.on("connected", async () => {
  console.log("✅ MongoDB connected successfully");

  try {
    await Contract.collection.createIndex({ id: 1 }, { unique: true });
    console.log("✅ Unique index on contract 'id' ensured");
  } catch (err) {
    console.error("⚠️ Error ensuring unique index on Contract.id:", err.message);
  }
});

mongoose.connection.on("error", (err) => {
  console.error("❌ MongoDB connection error:", err);
});

// ➤ POST /api/predict-demand
app.post("/api/predict-demand", async (req, res) => {
  try {
    const flaskRes = await axios.post("http://127.0.0.1:3002/predict", req.body);
    const predictionResult = flaskRes.data;

    // Optional: Save prediction to DB
    if (Prediction) {
      const newPrediction = new Prediction({
        ...req.body,
        predicted_demand: predictionResult.predicted_demand,
      });
      await newPrediction.save();
    }

    res.json(predictionResult);
  } catch (error) {
    console.error("❌ Error contacting ML server:", error.message);
    res.status(500).json({ error: "Failed to contact ML server" });
  }
});

// ➤ POST /farmers
app.post("/farmers", async (req, res) => {
  try {
    const { id, name, location, crops, contact } = req.body;
    if (!id || !name) return res.status(400).json({ error: "Farmer ID and name are required" });

    const exists = await Farmer.findOne({ id });
    if (exists) return res.status(409).json({ error: "Farmer with this ID already exists" });

    const newFarmer = new Farmer({ id, name, location, crops, contact });
    await newFarmer.save();
    res.status(201).json({ message: "Farmer added", farmer: newFarmer });
  } catch (err) {
    console.error("❌ Error adding farmer:", err.message);
    res.status(500).json({ error: "Error adding farmer" });
  }
});

// ➤ POST /buyers
app.post("/buyers", async (req, res) => {
  try {
    const { id, name, organization, crop_interests, contact } = req.body;
    if (!id || !name) return res.status(400).json({ error: "Buyer ID and name are required" });

    const exists = await Buyer.findOne({ id });
    if (exists) return res.status(409).json({ error: "Buyer with this ID already exists" });

    const newBuyer = new Buyer({ id, name, organization, crop_interests, contact });
    await newBuyer.save();
    res.status(201).json({ message: "Buyer added", buyer: newBuyer });
  } catch (err) {
    console.error("❌ Error adding buyer:", err.message);
    res.status(500).json({ error: "Error adding buyer" });
  }
});

// ➤ POST /contracts
app.post("/contracts", async (req, res) => {
  try {
    const { id, crop, quantity, price_per_kg, farmer_id, buyer_id, contract_date, delivery_date } = req.body;

    if (!id || !crop || !quantity || !price_per_kg || !farmer_id || !buyer_id) {
      return res.status(400).json({ error: "Missing required contract fields" });
    }

    const existing = await Contract.findOne({ id });
    if (existing) return res.status(409).json({ error: "Contract with this ID already exists" });

    const farmer = await Farmer.findOne({ id: farmer_id });
    const buyer = await Buyer.findOne({ id: buyer_id });

    if (!farmer || !buyer) {
      return res.status(404).json({ error: "Farmer or Buyer not found with given ID" });
    }

    const newContract = new Contract({
      id,
      crop,
      quantity,
      price_per_kg,
      farmer: farmer._id,
      buyer: buyer._id,
      contract_date: contract_date ? new Date(contract_date) : undefined,
      delivery_date: delivery_date ? new Date(delivery_date) : undefined,
    });

    await newContract.save();
    res.status(201).json({ message: "Contract created", contract: newContract });
  } catch (err) {
    if (err.code === 11000 && err.keyPattern?.id) {
      return res.status(400).json({ error: "Duplicate contract ID not allowed" });
    }
    console.error("❌ Error creating contract:", err.message);
    res.status(500).json({ error: "Error creating contract" });
  }
});

// ➤ GET /contracts
app.get("/contracts", async (req, res) => {
  try {
    const contracts = await Contract.find()
      .populate("farmer", "name id")
      .populate("buyer", "name id");

    const enrichedContracts = contracts.map((contract) => ({
      ...contract._doc,
      farmer_name: contract.farmer?.name || "Unknown",
      buyer_name: contract.buyer?.name || "Unknown",
      farmer_id: contract.farmer?.id || null,
      buyer_id: contract.buyer?.id || null,
    }));

    res.json(enrichedContracts);
  } catch (err) {
    console.error("❌ Error fetching contracts:", err.message);
    res.status(500).json({ error: "Error fetching contracts" });
  }
});

// ➤ GET /market-assessment
app.get("/market-assessment", async (req, res) => {
  try {
    const contracts = await Contract.find();
    if (contracts.length === 0) return res.json([]);

    const cropMap = {};
    contracts.forEach(({ crop, quantity, price_per_kg }) => {
      if (!cropMap[crop]) cropMap[crop] = { total_quantity: 0, total_price: 0, count: 0 };
      cropMap[crop].total_quantity += quantity;
      cropMap[crop].total_price += price_per_kg;
      cropMap[crop].count += 1;
    });

    const assessment = Object.entries(cropMap).map(([crop, data]) => ({
      crop,
      avg_price: parseFloat((data.total_price / data.count).toFixed(2)),
      avg_quantity: parseFloat((data.total_quantity / data.count).toFixed(2)),
    }));

    for (const entry of assessment) {
      await MarketAssessment.findOneAndUpdate(
        { crop: entry.crop },
        { ...entry, created_at: new Date() },
        { upsert: true }
      );
    }

    res.json(assessment);
  } catch (err) {
    console.error("❌ Error generating market assessment:", err.message);
    res.status(500).json({ error: "Error generating market assessment" });
  }
});

// ✅ FIXED ➤ GET /api/counts
app.get("/api/counts", async (req, res) => {
  try {
    const farmers = await Farmer.countDocuments();
    const buyers = await Buyer.countDocuments();
    const contracts = await Contract.countDocuments();

    let predictions = 0;
    try {
      predictions = await Prediction.countDocuments();
    } catch {
      predictions = 0;
    }

    res.json({ farmers, buyers, contracts, predictions });
  } catch (error) {
    console.error("❌ Error fetching counts:", error.message);
    res.status(500).json({ error: "Failed to fetch counts" });
  }
});

// ➤ Start server
app.listen(3001, () => {
  console.log("✅ Node.js backend running at http://localhost:3001");
});