const mongoose = require("mongoose");

const farmerSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true }, // Enforce unique ID
  name: { type: String, required: true },
  location: { type: String },
  crops: [String],
  contact: { type: String },
});

module.exports = mongoose.models.Farmer || mongoose.model("Farmer", farmerSchema);
