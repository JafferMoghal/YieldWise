const mongoose = require("mongoose");

const contractSchema = new mongoose.Schema({
  id: {
    type: Number,
    required: true,
    unique: true // Ensures uniqueness in validation
  },
  crop: { type: String, required: true },
  quantity: { type: Number, required: true },
  price_per_kg: { type: Number, required: true },
  farmer: { type: mongoose.Schema.Types.ObjectId, ref: "Farmer", required: true },
  buyer: { type: mongoose.Schema.Types.ObjectId, ref: "Buyer", required: true },
  contract_date: { type: Date, default: Date.now },
  delivery_date: { type: Date }
});

// ✅ Explicitly create unique index on 'id' to enforce at DB level
contractSchema.index({ id: 1 }, { unique: true });

module.exports = mongoose.models.Contract || mongoose.model("Contract", contractSchema);
