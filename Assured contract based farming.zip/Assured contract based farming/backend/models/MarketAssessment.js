const mongoose = require("mongoose");

const marketAssessmentSchema = new mongoose.Schema({
  crop: String,
  avg_price: Number,
  avg_quantity: Number,
  created_at: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.models.MarketAssessment || mongoose.model("MarketAssessment", marketAssessmentSchema);
