const mongoose = require("mongoose");

const buyerSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true }, // Enforce unique ID
  name: { type: String, required: true },
  organization: { type: String },
  crop_interests: [String],
  contact: { type: String },
});

module.exports = mongoose.models.Buyer || mongoose.model("Buyer", buyerSchema);
