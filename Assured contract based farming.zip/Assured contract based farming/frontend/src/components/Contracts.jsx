// src/components/Contracts.js
import React, { useState } from "react";
import axios from "axios";
import "./Contracts.css";

function Contracts() {
  const [contracts, setContracts] = useState([]);
  const [error, setError] = useState("");

  const fetchContracts = async () => {
    try {
      const res = await axios.get("http://localhost:3001/contracts");
      setContracts(res.data);
      setError("");
    } catch (err) {
      console.error("Error fetching contracts:", err);
      setError("Could not load contracts.");
    }
  };

  // Helper to format date nicely
  const formatDate = (dateStr) => {
    if (!dateStr) return "N/A";
    return new Date(dateStr).toLocaleDateString();
  };

  return (
    <div className="contracts-container">
      <h2>📜 Contracts</h2>
      <button onClick={fetchContracts}>Load Contracts</button>

      {error && <p className="error">{error}</p>}

      {contracts.length > 0 && (
        <ul className="contracts-list">
          {contracts.map((contract, index) => (
            <li key={index}>
              <strong>{contract.crop}</strong> | Quantity: {contract.quantity} kg | Price: ₹{contract.price_per_kg}/kg
              <br />
              Farmer: {contract.farmer_name}, Buyer: {contract.buyer_name}
              <br />
              Contract Date: {formatDate(contract.contract_date)}, Delivery Date: {formatDate(contract.delivery_date)}
              <hr />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Contracts;
