import React, { useState } from "react";
import axios from "axios";
import "./PredictDemandForm.css";

function PredictDemandForm() {
  const [showForm, setShowForm] = useState(false);
  const [crop, setCrop] = useState("");
  const [price, setPrice] = useState("");
  const [season, setSeason] = useState("");
  const [region, setRegion] = useState("");
  const [grade, setGrade] = useState("");
  const [marketType, setMarketType] = useState("");
  const [prediction, setPrediction] = useState(null);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post("http://localhost:3001/api/predict-demand", {
        crop,
        price_per_kg: parseFloat(price),
        season,
        region,
        grade,
        market_type: marketType,
      });

      setPrediction(res.data.predicted_quantity);
      setError("");
    } catch (err) {
      console.error("Prediction error:", err);
      setError("Prediction failed. Please check inputs or try again later.");
      setPrediction(null);
    }
  };

  return (
    <div className="predict-form-wrapper">
      <button className="toggle-button" onClick={() => setShowForm(!showForm)}>
        {showForm ? "Hide Demand Prediction" : "📊 Tap for Demand Prediction"}
      </button>

      {showForm && (
        <div className="predict-form-container">
          <h2>📈 Demand Prediction</h2>
          <form onSubmit={handleSubmit}>
            <div>
              <label>Crop:</label>
              <input
                type="text"
                value={crop}
                onChange={(e) => setCrop(e.target.value)}
                placeholder="e.g., Wheat"
                required
              />
            </div>
            <div>
              <label>Price per kg:</label>
              <input
                type="number"
                step="0.01"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="e.g., 22.5"
                required
              />
            </div>
            <div>
              <label>Season:</label>
              <select value={season} onChange={(e) => setSeason(e.target.value)} required>
                <option value="">--Select Season--</option>
                <option value="Rabi">Rabi</option>
                <option value="Kharif">Kharif</option>
                <option value="Zaid">Zaid</option>
              </select>
            </div>
            <div>
              <label>Region:</label>
              <input
                type="text"
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                placeholder="e.g., North"
                required
              />
            </div>
            <div>
              <label>Grade:</label>
              <select value={grade} onChange={(e) => setGrade(e.target.value)} required>
                <option value="">--Select Grade--</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
            <div>
              <label>Market Type:</label>
              <select value={marketType} onChange={(e) => setMarketType(e.target.value)} required>
                <option value="">--Select Market Type--</option>
                <option value="Retail">Retail</option>
                <option value="Wholesale">Wholesale</option>
              </select>
            </div>

            <button type="submit">Predict</button>
          </form>

          {prediction !== null && (
            <p className="prediction-result">
              📦 Predicted Quantity Demanded: <strong>{prediction.toFixed(2)}</strong>
            </p>
          )}

          {error && <p className="error">{error}</p>}
        </div>
      )}
    </div>
  );
}

export default PredictDemandForm;
