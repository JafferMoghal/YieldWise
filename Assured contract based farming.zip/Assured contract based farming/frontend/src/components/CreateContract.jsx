import React, { useState } from "react";
import api from "../api";
import "./CreateContract.css"; // Import the CSS file

const CreateContract = () => {
  const [id, setId] = useState("");
  const [farmerId, setFarmerId] = useState("");
  const [buyerId, setBuyerId] = useState("");
  const [crop, setCrop] = useState("");
  const [quantity, setQuantity] = useState("");
  const [pricePerKg, setPricePerKg] = useState("");
  const [contractDate, setContractDate] = useState("");
  const [deliveryDate, setDeliveryDate] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !id || !farmerId || !buyerId || !crop ||
      !quantity || !pricePerKg || !contractDate || !deliveryDate
    ) {
      alert("Please fill all contract fields.");
      return;
    }

    const parsedQuantity = Number(quantity);
    const parsedPricePerKg = Number(pricePerKg);
    const parsedId = Number(id);
    const parsedFarmerId = Number(farmerId);
    const parsedBuyerId = Number(buyerId);

    if (isNaN(parsedQuantity) || parsedQuantity <= 0) {
      alert("Quantity must be a positive number.");
      return;
    }
    if (isNaN(parsedPricePerKg) || parsedPricePerKg <= 0) {
      alert("Price per kg must be a positive number.");
      return;
    }
    if (isNaN(parsedId) || parsedId <= 0) {
      alert("ID must be a positive number.");
      return;
    }
    if (isNaN(parsedFarmerId) || parsedFarmerId <= 0) {
      alert("Farmer ID must be a positive number.");
      return;
    }
    if (isNaN(parsedBuyerId) || parsedBuyerId <= 0) {
      alert("Buyer ID must be a positive number.");
      return;
    }

    try {
      await api.post("/contracts", {
        id: parsedId,
        farmer_id: parsedFarmerId,
        buyer_id: parsedBuyerId,
        crop,
        quantity: parsedQuantity,
        price_per_kg: parsedPricePerKg,
        contract_date: contractDate,
        delivery_date: deliveryDate,
      });
      alert("Contract created successfully!");
      setId("");
      setFarmerId("");
      setBuyerId("");
      setCrop("");
      setQuantity("");
      setPricePerKg("");
      setContractDate("");
      setDeliveryDate("");
    } catch (err) {
      alert("Error creating contract: " + (err.response?.data?.error || err.message));
    }
  };

  return (
    <div className="contract-form-container">
      <h2>Create Contract</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>ID:</label>
          <input type="number" value={id} onChange={(e) => setId(e.target.value)} required />
        </div>
        <div>
          <label>Farmer ID:</label>
          <input type="number" value={farmerId} onChange={(e) => setFarmerId(e.target.value)} required />
        </div>
        <div>
          <label>Buyer ID:</label>
          <input type="number" value={buyerId} onChange={(e) => setBuyerId(e.target.value)} required />
        </div>
        <div>
          <label>Crop:</label>
          <select value={crop} onChange={(e) => setCrop(e.target.value)} required>
            <option value="">-- Select Crop --</option>
            <option value="Rice">Rice</option>
            <option value="Wheat">Wheat</option>
            <option value="Maize">Maize</option>
            <option value="Sorghum">Sorghum</option>
            <option value="Barley">Barley</option>
          </select>
        </div>
        <div>
          <label>Quantity:</label>
          <input type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
        </div>
        <div>
          <label>Price per kg:</label>
          <input type="number" value={pricePerKg} onChange={(e) => setPricePerKg(e.target.value)} required />
        </div>
        <div>
          <label>Contract Date:</label>
          <input type="date" value={contractDate} onChange={(e) => setContractDate(e.target.value)} required />
        </div>
        <div>
          <label>Delivery Date:</label>
          <input type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} required />
        </div>
        <button type="submit">Create Contract</button>
      </form>
    </div>
  );
};

export default CreateContract;
