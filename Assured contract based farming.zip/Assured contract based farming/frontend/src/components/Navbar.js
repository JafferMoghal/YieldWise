import React from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav style={{
      backgroundColor: "rgba(0, 128, 0, 0.85)",
      padding: "12px 24px",
      color: "white",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }}>
      <div style={{ fontSize: "24px", fontWeight: "bold" }}>YIELD WISE</div>
      <div style={{ display: "flex", gap: "20px" }}>
        <Link to="/" style={linkStyle}>Home</Link>
        <Link to="/add-farmer" style={linkStyle}>Add Farmer</Link>
        <Link to="/add-buyer" style={linkStyle}>Add Buyer</Link>
        <Link to="/create-contract" style={linkStyle}>Create Contract</Link>
        <Link to="/contracts" style={linkStyle}>Contracts</Link>
        <Link to="/market-assessment" style={linkStyle}>Market Assessment</Link>
        <Link to="/predict" style={linkStyle}>Predict</Link>
      </div>
    </nav>
  );
}

const linkStyle = {
  color: "white",
  textDecoration: "none",
  fontWeight: "500"
};
