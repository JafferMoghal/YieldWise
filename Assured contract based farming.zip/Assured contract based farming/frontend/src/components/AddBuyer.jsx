// src/components/AddBuyer.js
import React, { useState } from "react";
import api from "../api";
import "./AddBuyer.css"; // Import the CSS file

const AddBuyer = () => {
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!id || !name || !location) {
      alert("Please fill all fields.");
      return;
    }

    const parsedId = Number(id);
    if (isNaN(parsedId) || parsedId <= 0) {
      alert("ID must be a positive number.");
      return;
    }

    try {
      await api.post("/buyers", { id: parsedId, name, location });
      alert("Buyer added successfully!");
      setId("");
      setName("");
      setLocation("");
    } catch (err) {
      alert("Error adding buyer: " + (err.response?.data || err.message));
    }
  };

  return (
    <div className="form-container">
      <h2>Add Buyer</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>ID:</label>
          <input
            type="number"
            value={id}
            onChange={(e) => setId(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Location:</label>
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </div>
        <button type="submit">Add Buyer</button>
      </form>
    </div>
  );
};

export default AddBuyer;
