// src/components/MarketAssessment.js
import React, { useEffect, useState } from "react";
import "./MarketAssessment.css";

function MarketAssessment() {
  const [data, setData] = useState([]);
  const [error, setError] = useState("");

  const loadMarketData = async () => {
    try {
      const response = await fetch("http://localhost:3001/market-assessment");
      if (!response.ok) throw new Error("Failed to fetch market data");

      const result = await response.json();
      setData(result);
      setError("");
    } catch (err) {
      console.error("Error loading market assessment:", err);
      setError("Could not load market assessment data.");
      setData([]);
    }
  };

  useEffect(() => {
    loadMarketData();
  }, []);

  return (
    <div className="market-container">
      <h2>📊 Market Assessment</h2>
      <button onClick={loadMarketData}>Reload Market Assessment</button>

      {error && <p className="error">{error}</p>}

      {data.length > 0 ? (
        <table className="market-table">
          <thead>
            <tr>
              <th>Crop</th>
              <th>Average Price (₹/kg)</th>
              <th>Average Quantity</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr key={index}>
                <td>{item.crop}</td>
                <td>{item.avg_price}</td>
                <td>{item.avg_quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        !error && <p>No data loaded yet.</p>
      )}
    </div>
  );
}

export default MarketAssessment;
