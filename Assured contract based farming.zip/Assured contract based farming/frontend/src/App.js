import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import axios from "axios";

import AddFarmer from "./components/AddFarmer";
import AddBuyer from "./components/AddBuyer";
import CreateContract from "./components/CreateContract";
import Contracts from "./components/Contracts";
import MarketAssessment from "./components/MarketAssessment";
import PredictDemandForm from "./components/PredictDemandForm";
import Login from "./components/LoginPage";
import Navbar from "./components/Navbar";
import "./App.css";

// Inline style for background image
const backgroundStyle = {
  backgroundImage: "url('/farm-bg.jpg')",
  backgroundSize: "cover",
  backgroundPosition: "center",
  backgroundRepeat: "no-repeat",
  backgroundAttachment: "fixed",
  minHeight: "100vh",
};

function Home() {
  const [stats, setStats] = useState({
    farmers: 0,
    buyers: 0,
    contracts: 0,
    predictions: 0,
  });

  useEffect(() => {
    axios.get("http://localhost:3001/api/counts")
      .then(res => setStats(res.data))
      .catch(err => console.error("Error fetching stats:", err));
  }, []);

  return (
    <>
      <div className="header-banner">
        <h1 className="app-title">YIELD WISE</h1>
        <h3 className="app-subtitle">Bridging Farmers and Buyers with Intelligent AI Insights</h3>
      </div>

      <div className="home-stats">
        <div className="stat-card">👨‍🌾 {stats.farmers} Farmers</div>
        <div className="stat-card">🛒 {stats.buyers} Buyers</div>
        <div className="stat-card">📃 {stats.contracts} Contracts</div>
        <div className="stat-card">📈 {stats.predictions} Predictions</div>
      </div>

      <div className="features-section">
        <h2>Platform Features</h2>
        <ul>
          <li>✅ AI-powered demand prediction</li>
          <li>✅ Hassle-free contract creation</li>
          <li>✅ Farmer and Buyer record management</li>
          <li>✅ Market assessment for smarter decisions</li>
        </ul>
      </div>

      <div className="quote-box">
        <p>"Empowering farmers with data is the seed of agricultural revolution."</p>
      </div>

      <footer className="footer">
        <p>© 2025 Yield Wise. All rights reserved.</p>
      </footer>
    </>
  );
}

function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  const handleLogin = () => {
    setLoggedIn(true);
  };

  if (!loggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <Router>
      <Navbar />
      <div className="app-container" style={backgroundStyle}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/add-farmer" element={<AddFarmer />} />
          <Route path="/add-buyer" element={<AddBuyer />} />
          <Route path="/create-contract" element={<CreateContract />} />
          <Route path="/contracts" element={<Contracts />} />
          <Route path="/market-assessment" element={<MarketAssessment />} />
          <Route path="/predict" element={<PredictDemandForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
